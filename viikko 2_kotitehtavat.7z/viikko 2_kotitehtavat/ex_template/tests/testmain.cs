using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static int Main(string[] args)
        {
            MyProgram.MyFunction(args);

            return 0;
        }
    }
}
