"""
KT5

Korjaa alla oleva funktio siten, että se palauttaa 'Olen antanut palautteen'

"""
#imports here

def palautteen_tila():
    return 'Olen antanut palautteen'  # Korjaa palautettu teksti

# Tulosta tulos varmistaaksesi, että se toimii oikein
print(palautteen_tila())




