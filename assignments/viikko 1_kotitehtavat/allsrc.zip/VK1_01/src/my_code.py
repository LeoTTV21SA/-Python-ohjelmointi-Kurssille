# -*- coding: utf-8 -*-

#
# KT1
#
# Esittele ja anna alkuarvot muuttujille (käytä muuttujanimiä ja arvoja, jotka suluissa muuttujien perässä),
# joihin pitäisi tallentaa seuraavat tiedot:
#
#
#
# piin likiarvo (pii, 3.14)
#
# lähiosoite (lahiosoite, Kauppakatu 12)
#
# henkilötunnus (henkilotunnus, 211278-234X)
#
# nimesi ensimmäinen kirjain (nimi_eka, j)
#
# tämän hetkinen lämpötila yhden desimaalin tarkkuudella(lampotila, 12.5)
#
#
#
# Tulosta arvot muuttujista allekkain.


pii = 3.14
print(pii)
lahiosoite = "Kauppakatu 12"
print(lahiosoite)
henkilotunnus = "211278-234X"
print(henkilotunnus)
nimi_eka = "j"
print(nimi_eka)
lampotila = 12.5
print(12.5)