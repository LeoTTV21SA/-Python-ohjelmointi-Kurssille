using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class MyProgram
    {
        public static void MyFunction(string[] args)
        {
            var s=Console.ReadLine();
            Console.WriteLine("a b c "+s);
        }
    }
}
